import React, { useState } from 'react'; 
import axios from 'axios'; 

function App() {
    const [functionn, setFunctionn] = useState(''); 
    const [symbol, setSymbol] = useState(''); 
    const [data, setData] = useState(''); 

    const searchData = async () => {
        try {
            const response = await axios.get('http://localhost:8080/data', {
                params: { functionn, symbol}
            });
            setData(response.data);
            
        } catch (error) {

            console.error('Error fetching data:', error);
        }
    };
    
    return (
        <div className="App">
            <input
                type="text"
                value={functionn}
                onChange={(e) => setFunctionn(e.target.value)}
                placeholder="Funcion"
            />
            <input
                type="text"
                value={symbol}
                onChange={(e) => setSymbol(e.target.value)}
                placeholder="Empresa"
            />
            <button onClick={searchData}>Search</button>
    
            {data && (
                <div>
                    <pre>{JSON.stringify(data, null, 2)}</pre>
                </div>
            )}
        </div>
    );
}

export default App; 
